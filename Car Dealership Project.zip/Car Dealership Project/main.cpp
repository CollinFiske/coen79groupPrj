#include "Cardealership.h"

int main() {
    CarDealership dealership;
    dealership.run();
    return 0;
}