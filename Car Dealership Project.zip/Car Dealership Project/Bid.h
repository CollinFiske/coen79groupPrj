#ifndef BID_H
#define BID_H

#include "Listing.h"

class Bid {
public:
    void display(Listing* item);
};

#endif